
t=1
mice=[]
cats=[]
starved_cat=0
random_dead_cat=0
random_dead_mouse=0
eaten_mouse=0
born_mouse=0
born_cat=0
mouse_life=[]
mouse_maturetime=[]
cat_life=[]
cat_maturetime=[]
mouse_size=[]
cat_size=[]
mno=[]
cno=[]
tli=[]


