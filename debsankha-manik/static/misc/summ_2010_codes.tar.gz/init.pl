init:-consult(generate_supersets),start,consult(categorize),categorize,consult(link),form_links,consult(form_rule),consult(write_rule).
