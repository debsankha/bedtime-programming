true([BQ,EB,XR]):-(=([],EB)),(=(BQ,XR)),(first(RS,BQ),first(YR,XR),=(RS,YR)),(tail(JI,BQ),tail(HD,XR),=(JI,HD)),1=1.
true([LG,ON,RL]):-tail(OF,LG),tail(WL,ON),true([OF,WL,RL]).
