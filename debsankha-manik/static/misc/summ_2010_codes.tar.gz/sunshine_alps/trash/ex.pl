similar_intermediate1(arguments(2,1),size(2,1),first_index(2,2),second_index(2,2)).
similar_intermediate1(arguments(2,1),size(2,2),first_index(3,3),second_index(3,3)).
similar_intermediate1(arguments(2,1),size(3,2),first_index(1,1),second_index(1,1)).
similar_intermediate1(arguments(2,1),size(1,1),first_index(4,4),second_index(4,4)).
similar_intermediate1(arguments(2,1),size(1,2),first_index(2,2),second_index(2,2)).




