tail(A,B):- =(B,[C|A]).
