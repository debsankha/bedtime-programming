memory_predicates([first,tail]).
