<equals>
1	3	[]	[]	
1	3	[first]	[first]	
1	3	[tail]	[tail]	
</equals>
<nulls>
2
</nulls>
<diffs>
1	[tail]
2	[tail]
</diffs>
<len>3</len>