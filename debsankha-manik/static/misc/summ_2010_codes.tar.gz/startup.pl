[generate_supersets].
start.

[categorize].
categorize.
