true_fact(MN,XR,CQ):-(=([],XR)),(=(MN,CQ)),(first(KQ,MN),first(GY,CQ),=(KQ,GY)),(tail(LJ,MN),tail(BE,CQ),=(LJ,BE)),1=1.
true_fact(JK,RK,BV):-tail(PD,JK),tail(TY,RK),true_fact(PD,TY,BV).
