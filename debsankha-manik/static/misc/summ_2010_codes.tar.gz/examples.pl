:-dynamic(true/1).

true([[a,b,c,d,e],[a,b,c],[d,e]]).

