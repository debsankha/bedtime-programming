python montecarlo.py > /dev/null &
echo "1st one running"
python simple.py > /dev/null &
echo "2nd one is running"

